var config = {
    "apikey"    : "APPLICATION_KEY",
    "clientkey" : "CLIENT_KEY",
    "apiserver" : {
        "stub" : false
    },
  };